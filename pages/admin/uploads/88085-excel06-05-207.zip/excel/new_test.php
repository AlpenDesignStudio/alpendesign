<style>
table {
    border-collapse: separate;
	background-color: #FFFFFF;
    border-spacing: 0;
    width: 50%;
	color: #666666;
    text-shadow: 0 1px 0 #FFFFFF;
	border: 1px solid #CCCCCC;
	box-shadow: 0 5px 5px -5px rgba(0, 0, 0, 0.3);
	margin: 0 auto;
	font-family: arial;
	margin-top: 20px;
}
table thead tr th {
    background: none repeat scroll 0 0 #EEEEEE;
    color: #222222;
    padding: 10px 14px;
    text-align: left;
	border-top: 0 none;
	font-size: 12px;
}
table tbody tr td{
    background-color: #FFFFFF;
	font-size: 11px;
    text-align: left;
	padding: 10px 14px;
	border-top: 1px solid #DDDDDD;
}
#pagination {
	text-align: center;
	margin-top: 20px;
}
#pagination a {
	border: 1px solid #CCCCCC;
	padding: 5px 10px;
	font-family: arial;
	text-decoration: none;
	background: none repeat scroll 0 0 #EEEEEE;
	color: #222222;
}
#pagination a:hover {
	background-color: #FFFFFF;
}
a#active{
	background-color: #FFFFFF;
}
</style>

<table cellspacing="0" cellpadding="2" >
<thead>
	<tr>
		<th>Date</th>
			<th>BTB</th>
			<th>Task</th>
			<th>Project Name</th>
			<th>Task Type</th>
			<th>Company ID</th>
			<th>Staff ID</th>
			<th>Parent ID</th>
			<th>Reference Code</th>
			<th>Company Received</th>
			<th>Company Name</th>
			<th>Company Disposition</th>
			<th>Company Telephone</th>
			<th>Alternate Telephone</th>
			<th>Company Fax</th>
			<th>Company Email</th>
			<th>Address</th>
			<th>Address 2</th>
			<th>Address 3</th>
			<th>Post Code</th>
			<th>City</th>
			<th>State</th>
			<th>Country</th>
			<th>Address URL</th>
			<th>REGION</th>
			<th>WEBSITE</th>
			<th>Interest Area</th>
			<th>INDUSTRY</th>
			<th>Web Staff Disposition</th>
			<th>Voice Disposition</th>
			<th>Incomplete Disposition</th>
			<th>Researcher Remarks</th>
			<th>Caller Remarks</th>
			<th>Company Remarks</th>
			<th>Revenue (In Mil)</th>
			<th>Number of Employees</th>
			<th>SIC Code</th>
			<th>SIC Description</th>
			<th>CA 1</th>
			<th>CA 2</th>
			<th>CA 3</th>
			<th>CA 4</th>
			<th>CA 5</th>
			<th>Title</th>
			<th>First Name</th>
			<th>INITIALS</th>
			<th>LASTNAME</th>
			<th>SUFFIX</th>
			<th>Job Title</th>
			<th>Job Function</th>
			<th>Department</th>
			<th>Staff Url</th>
			<th>Staff Email</th>
			<th>Assumed Email</th>
			<th>Email Harvesting</th>
			<th>Direct Tel</th>
			<th>EXTENSION</th>
			<th>Direct Fax</th>
			<th>Mobile</th>
			<th>Voice Staff Disposition</th>
			<th>Staff Remarks</th>
			<th>SA 1</th>
			<th>SA 2</th>
			<th>SA 3</th>
			<th>SA 4</th>
			<th>SA 5</th>
			<th>Status</th>
			<th>Company General Notes</th>
			<th>Staff Notes</th>
			<th>Job Title Required</th>
			<th>Brief</th>
			<th>Web Disposition</th>
			<th>Staff Email Status</th>
			<th>Staff Email Status</th>
	</tr>
</thead>
<tbody>
	<?php
		if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
		$start_from = ($page-1) * 3; 		
		$result = $db_con->prepare("SELECT * FROM excel_data ORDER BY id ASC LIMIT $start_from, 3");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
	<tr class="record">
		<td><?php echo $row['date']; ?></td>
			<td><?php echo $row['btb']; ?></td>
			<td><?php echo $row['task']; ?></td>
			<td><?php echo $row['project_name']; ?></td>
			<td><?php echo $row['task_type']; ?></td>
			<td><?php echo $row['company_id']; ?></td>
			<td><?php echo $row['staff_id']; ?></td>
			<td><?php echo $row['parent_id']; ?></td>
			<td><?php echo $row['reference_code']; ?></td>
			<td><?php echo $row['company_received']; ?></td>
			<td><?php echo $row['company_name']; ?></td>
			<td><?php echo $row['company_disposition']; ?></td>
			<td><?php echo $row['company_telephone']; ?></td>
			<td><?php echo $row['alternate_telephone']; ?></td>
			<td><?php echo $row['company_fax']; ?></td>
			<td><?php echo $row['company_email']; ?></td>
			<td><?php echo $row['address']; ?></td>
			<td><?php echo $row['address_2']; ?></td>
			<td><?php echo $row['address_3']; ?></td>
			<td><?php echo $row['post_code']; ?></td>
			<td><?php echo $row['city']; ?></td>
			<td><?php echo $row['state']; ?></td>
			<td><?php echo $row['country']; ?></td>
			<td><?php echo $row['address_url']; ?></td>
			<td><?php echo $row['region']; ?></td>
			<td><?php echo $row['website']; ?></td>
			<td><?php echo $row['interest_area']; ?></td>
			<td><?php echo $row['industry']; ?></td>
			<td><?php echo $row['web_staff_disposition']; ?></td>
			<td><?php echo $row['voice_disposition']; ?></td>
			<td><?php echo $row['incomplete_disposition']; ?></td>
			<td><?php echo $row['researcher_remarks']; ?></td>
			<td><?php echo $row['caller_remarks']; ?></td>
			<td><?php echo $row['company_remarks']; ?></td>
			<td><?php echo $row['revenue_in_mil']; ?></td>
			<td><?php echo $row['number_of_employees']; ?></td>
			<td><?php echo $row['sic_code']; ?></td>
			<td><?php echo $row['sic_description']; ?></td>
			<td><?php echo $row['ca_1']; ?></td>
			<td><?php echo $row['ca_2']; ?></td>
			<td><?php echo $row['ca_3']; ?></td>
			<td><?php echo $row['ca_4']; ?></td>
			<td><?php echo $row['ca_5']; ?></td>
			<td><?php echo $row['title']; ?></td>
			<td><?php echo $row['first_name']; ?></td>
			<td><?php echo $row['initials']; ?></td>
			<td><?php echo $row['lastname']; ?></td>
			<td><?php echo $row['suffix']; ?></td>
			<td><?php echo $row['job_title']; ?></td>
			<td><?php echo $row['job_function']; ?></td>
			<td><?php echo $row['department']; ?></td>
			<td><?php echo $row['staff_url']; ?></td>
			<td><?php echo $row['staff_email']; ?></td>
			<td><?php echo $row['assumed_email']; ?></td>
			<td><?php echo $row['email_harvesting']; ?></td>
			<td><?php echo $row['direct_tel']; ?></td>
			<td><?php echo $row['extension']; ?></td>
			<td><?php echo $row['direct_fax']; ?></td>
			<td><?php echo $row['mobile']; ?></td>
			<td><?php echo $row['voice_staff_disposition']; ?></td>
			<td><?php echo $row['staff_remarks']; ?></td>
			<td><?php echo $row['sa_1']; ?></td>
			<td><?php echo $row['sa_2']; ?></td>
			<td><?php echo $row['sa_3']; ?></td>
			<td><?php echo $row['sa_4']; ?></td>
			<td><?php echo $row['sa_5']; ?></td>
			<td><?php echo $row['status']; ?></td>
			<td><?php echo $row['company_general_notes']; ?></td>
			<td><?php echo $row['staff_notes']; ?></td>
			<td><?php echo $row['job_title_required']; ?></td>
			<td><?php echo $row['brief']; ?></td>
			<td><?php echo $row['web_disposition']; ?></td>
			<td><?php echo $row['staff_email_status']; ?></td>
	</tr>
	<?php
		}
	?>
</tbody>
</table>
<div id="pagination">
	<?php 

	$result = $db_con->prepare("SELECT COUNT(id) FROM excel_data");
	$result->execute(); 
	$row = $result->fetch(); 
	$total_records = $row[0]; 
	$total_pages = ceil($total_records / 3); 
	  
	for ($i=1; $i<=$total_pages; $i++) { 
				echo "<a href='view_data.php?page=".$i."'";
				if($page==$i)
				{
				echo "id=active";
				}
				echo ">";
				echo "".$i."</a> "; 
	}; 
	?>
</div>