<?php
$servername = 'localhost';
$username = 'thewhite_excel';
$password = 'pass@12345';
$db = 'thewhite_excel';
$db_con = new PDO("mysql:host=".$servername.";dbname=".$db, $username, $password);
$con_status = $db_con->getAttribute(PDO::ATTR_CONNECTION_STATUS);
// if($con_status !== 0){
	// echo 'connected';
// }else {
	// echo 'no data';
// }

// User: thewhite_excel 
// Database: thewhite_excel
// password : pass@12345
?>

