<?php
include($_SERVER['DOCUMENT_ROOT']."/excel/config.php"); 
	
$btb=$_POST['ddl_btb'];
$task=$_POST['ddl_task'];
$proj_name=$_POST['ddl_proj_name'];
$task_type=$_POST['ddl_task_type'];
$company_id=$_POST['ddl_company_id'];
$company_name=$_POST['ddl_company_name'];
$state=$_POST['ddl_state'];
$country=$_POST['ddl_country'];
$website=$_POST['ddl_website'];
$industry=$_POST['ddl_industry'];
$no_of_emp=$_POST['ddl_no_of_emp'];
$f_name=$_POST['ddl_f_name'];
$l_name=$_POST['ddl_l_name'];
$job_title=$_POST['ddl_job_title'];
$job_func=$_POST['ddl_job_func'];
$staff_email=$_POST['ddl_staff_email'];

$WhereAnd = 'where';
function getWhereAnd() {
  global $WhereAnd;
  if ($WhereAnd == 'where') {
    $WhereAnd = 'and';
    return ' where ';
  } else {
    return ' and ';
  }
}

$limit=10;
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
		$start_from = ($page-1) * 3; 



$q = 'SELECT * FROM excel_data'; 

	 if(!empty($btb)){
		$q .=  getWhereAnd() . "btb=:btb";
		$args[':btb']=$btb;
	 }
	 if(!empty($task)){
		  $q .=  getWhereAnd() . "task=:task";
		  $args[':task']=$task;
		}	
	 if(!empty($proj_name)){
		$q .=  getWhereAnd() . "project_name=:proj_name";
		$args[':proj_name']=$proj_name;
		}
	 if(!empty($task_type)){
		 $q .=  getWhereAnd() . "task_type=:task_type";
		 $args[':task_type']=$task_type;
		}
	 if(!empty($company_id)){
		 $q .=  getWhereAnd() . "company_id=:company_id";
		 $args[':company_id']=$company_id;
		}
	 if(!empty($company_name)){	
		 $q .=  getWhereAnd() . "company_name=:company_name";
		 $args[':company_name']=$company_name;
		}
	 if(!empty($state)){
		 $q .=  getWhereAnd() . "state=:state";
		 $args[':state']=$state;
		}
	if(!empty($country)){
		$q .=  getWhereAnd() . "country=:country";
		$args[':country']=$country;
		}
	 if(!empty($website)){
		 $q .=  getWhereAnd() . "website=:website";
		 $args[':website']=$website;
		}
	if(!empty($industry)){	
		$q .=  getWhereAnd() . "industry=:industry";
		$args[':industry']=$industry;
		}
	 if(!empty($no_of_emp)){	
		$q .=  getWhereAnd() . "number_of_employees=:no_of_emp";
		$args[':no_of_emp']=$no_of_emp;		
			}
	if(!empty($f_name)){	
		$q .=  getWhereAnd() . "first_name=:f_name";
		$args[':f_name']=$f_name;
		}
	 if(!empty($l_name)){	
		$q .=  getWhereAnd() . "last_name=:l_name";
		$args[':l_name']=$l_name;		
		}
	if(!empty($job_title)){	
		$q .=  getWhereAnd() . "job_title=:job_title";
		$args[':job_title']=$job_title;
		}
	if(!empty($job_func)){		
		$q .=  getWhereAnd() . "job_function=:job_func";
		$args[':job_func']=$job_func;
		}
	if(!empty($staff_url)){	
		$q .=  getWhereAnd() . "staff_url=:staff_url";
		$args[':staff_url']=$staff_url;
		}	
	 if(!empty($staff_url)){	
	 $q .=  getWhereAnd() . "staff_email=:staff_email";
	 $args[':staff_email']=$staff_email;
		}

	$q.=  " ORDER BY job_function ASC LIMIT " . $start_from .','.$limit;
	 echo $q;
	$result=$db_con->prepare($q);
	$result->execute($args);
	
?>

<div class="row">
 <?php
 if($result->rowCount() > 0){ 
  ?>
  <thead>
		<tr>
			<th>Date</th>
			<th>BTB</th>
			<th>Task</th>
			<th>Project Name</th>
			<th>Task Type</th>
			<th>Company ID</th>
			<th>Staff ID</th>
			<th>Parent ID</th>
			<th>Reference Code</th>
			<th>Company Received</th>
			<th>Company Name</th>
			<th>Company Disposition</th>
			<th>Company Telephone</th>
			<th>Alternate Telephone</th>
			<th>Company Fax</th>
			<th>Company Email</th>
			<th>Address</th>
			<th>Address 2</th>
			<th>Address 3</th>
			<th>Post Code</th>
			<th>City</th>
			<th>State</th>
			<th>Country</th>
			<th>Address URL</th>
			<th>REGION</th>
			<th>WEBSITE</th>
			<th>Interest Area</th>
			<th>INDUSTRY</th>
			<th>Web Staff Disposition</th>
			<th>Voice Disposition</th>
			<th>Incomplete Disposition</th>
			<th>Researcher Remarks</th>
			<th>Caller Remarks</th>
			<th>Company Remarks</th>
			<th>Revenue (In Mil)</th>
			<th>Number of Employees</th>
			<th>SIC Code</th>
			<th>SIC Description</th>
			<th>CA 1</th>
			<th>CA 2</th>
			<th>CA 3</th>
			<th>CA 4</th>
			<th>CA 5</th>
			<th>Title</th>
			<th>First Name</th>
			<th>INITIALS</th>
			<th>LASTNAME</th>
			<th>SUFFIX</th>
			<th>Job Title</th>
			<th>Job Function</th>
			<th>Department</th>
			<th>Staff Url</th>
			<th>Staff Email</th>
			<th>Assumed Email</th>
			<th>Email Harvesting</th>
			<th>Direct Tel</th>
			<th>EXTENSION</th>
			<th>Direct Fax</th>
			<th>Mobile</th>
			<th>Voice Staff Disposition</th>
			<th>Staff Remarks</th>
			<th>SA 1</th>
			<th>SA 2</th>
			<th>SA 3</th>
			<th>SA 4</th>
			<th>SA 5</th>
			<th>Status</th>
			<th>Company General Notes</th>
			<th>Staff Notes</th>
			<th>Job Title Required</th>
			<th>Brief</th>
			<th>Web Disposition</th>
			<th>Staff Email Status</th>
			<th>Staff Email Status</th>
		</tr>
	</thead>
 <?php
	//$results = $db_con->prepare("SELECT COUNT(id) FROM excel_data");
  $total_records = $result->rowCount();
	$total_pages = ceil($total_records / $limit);  
	$pagLink = "<div class='pagination'>";  
	for ($i=1; $i<=$total_pages; $i++) {  
    $pagLink .= "<a href='view_data.php?page=".$i."'>".$i."</a>";  


  while($row=$result->fetch(PDO::FETCH_ASSOC))
  {
 ?>
 
	<tbody>
		<tr>
			<td><?php echo $row['date']; ?></td>
			<td><?php echo $row['btb']; ?></td>
			<td><?php echo $row['task']; ?></td>
			<td><?php echo $row['project_name']; ?></td>
			<td><?php echo $row['task_type']; ?></td>
			<td><?php echo $row['company_id']; ?></td>
			<td><?php echo $row['staff_id']; ?></td>
			<td><?php echo $row['parent_id']; ?></td>
			<td><?php echo $row['reference_code']; ?></td>
			<td><?php echo $row['company_received']; ?></td>
			<td><?php echo $row['company_name']; ?></td>
			<td><?php echo $row['company_disposition']; ?></td>
			<td><?php echo $row['company_telephone']; ?></td>
			<td><?php echo $row['alternate_telephone']; ?></td>
			<td><?php echo $row['company_fax']; ?></td>
			<td><?php echo $row['company_email']; ?></td>
			<td><?php echo $row['address']; ?></td>
			<td><?php echo $row['address_2']; ?></td>
			<td><?php echo $row['address_3']; ?></td>
			<td><?php echo $row['post_code']; ?></td>
			<td><?php echo $row['city']; ?></td>
			<td><?php echo $row['state']; ?></td>
			<td><?php echo $row['country']; ?></td>
			<td><?php echo $row['address_url']; ?></td>
			<td><?php echo $row['region']; ?></td>
			<td><?php echo $row['website']; ?></td>
			<td><?php echo $row['interest_area']; ?></td>
			<td><?php echo $row['industry']; ?></td>
			<td><?php echo $row['web_staff_disposition']; ?></td>
			<td><?php echo $row['voice_disposition']; ?></td>
			<td><?php echo $row['incomplete_disposition']; ?></td>
			<td><?php echo $row['researcher_remarks']; ?></td>
			<td><?php echo $row['caller_remarks']; ?></td>
			<td><?php echo $row['company_remarks']; ?></td>
			<td><?php echo $row['revenue_in_mil']; ?></td>
			<td><?php echo $row['number_of_employees']; ?></td>
			<td><?php echo $row['sic_code']; ?></td>
			<td><?php echo $row['sic_description']; ?></td>
			<td><?php echo $row['ca_1']; ?></td>
			<td><?php echo $row['ca_2']; ?></td>
			<td><?php echo $row['ca_3']; ?></td>
			<td><?php echo $row['ca_4']; ?></td>
			<td><?php echo $row['ca_5']; ?></td>
			<td><?php echo $row['title']; ?></td>
			<td><?php echo $row['first_name']; ?></td>
			<td><?php echo $row['initials']; ?></td>
			<td><?php echo $row['lastname']; ?></td>
			<td><?php echo $row['suffix']; ?></td>
			<td><?php echo $row['job_title']; ?></td>
			<td><?php echo $row['job_function']; ?></td>
			<td><?php echo $row['department']; ?></td>
			<td><?php echo $row['staff_url']; ?></td>
			<td><?php echo $row['staff_email']; ?></td>
			<td><?php echo $row['assumed_email']; ?></td>
			<td><?php echo $row['email_harvesting']; ?></td>
			<td><?php echo $row['direct_tel']; ?></td>
			<td><?php echo $row['extension']; ?></td>
			<td><?php echo $row['direct_fax']; ?></td>
			<td><?php echo $row['mobile']; ?></td>
			<td><?php echo $row['voice_staff_disposition']; ?></td>
			<td><?php echo $row['staff_remarks']; ?></td>
			<td><?php echo $row['sa_1']; ?></td>
			<td><?php echo $row['sa_2']; ?></td>
			<td><?php echo $row['sa_3']; ?></td>
			<td><?php echo $row['sa_4']; ?></td>
			<td><?php echo $row['sa_5']; ?></td>
			<td><?php echo $row['status']; ?></td>
			<td><?php echo $row['company_general_notes']; ?></td>
			<td><?php echo $row['staff_notes']; ?></td>
			<td><?php echo $row['job_title_required']; ?></td>
			<td><?php echo $row['brief']; ?></td>
			<td><?php echo $row['web_disposition']; ?></td>
			<td><?php echo $row['staff_email_status']; ?></td>
		</tr>
	</tbody>
   <?php  
    
  }
 };  
echo $pagLink . "</div>"; 
  
 }else{
  
  ?> 
  <thead>
		<tr>
			<th>Date</th>
			<th>BTB</th>
			<th>Task</th>
			<th>Project Name</th>
			<th>Task Type</th>
			<th>Company ID</th>
			<th>Staff ID</th>
			<th>Parent ID</th>
			<th>Reference Code</th>
			<th>Company Received</th>
			<th>Company Name</th>
			<th>Company Disposition</th>
			<th>Company Telephone</th>
			<th>Alternate Telephone</th>
			<th>Company Fax</th>
			<th>Company Email</th>
			<th>Address</th>
			<th>Address 2</th>
			<th>Address 3</th>
			<th>Post Code</th>
			<th>City</th>
			<th>State</th>
			<th>Country</th>
			<th>Address URL</th>
			<th>REGION</th>
			<th>WEBSITE</th>
			<th>Interest Area</th>
			<th>INDUSTRY</th>
			<th>Web Staff Disposition</th>
			<th>Voice Disposition</th>
			<th>Incomplete Disposition</th>
			<th>Researcher Remarks</th>
			<th>Caller Remarks</th>
			<th>Company Remarks</th>
			<th>Revenue (In Mil)</th>
			<th>Number of Employees</th>
			<th>SIC Code</th>
			<th>SIC Description</th>
			<th>CA 1</th>
			<th>CA 2</th>
			<th>CA 3</th>
			<th>CA 4</th>
			<th>CA 5</th>
			<th>Title</th>
			<th>First Name</th>
			<th>INITIALS</th>
			<th>LASTNAME</th>
			<th>SUFFIX</th>
			<th>Job Title</th>
			<th>Job Function</th>
			<th>Department</th>
			<th>Staff Url</th>
			<th>Staff Email</th>
			<th>Assumed Email</th>
			<th>Email Harvesting</th>
			<th>Direct Tel</th>
			<th>EXTENSION</th>
			<th>Direct Fax</th>
			<th>Mobile</th>
			<th>Voice Staff Disposition</th>
			<th>Staff Remarks</th>
			<th>SA 1</th>
			<th>SA 2</th>
			<th>SA 3</th>
			<th>SA 4</th>
			<th>SA 5</th>
			<th>Status</th>
			<th>Company General Notes</th>
			<th>Staff Notes</th>
			<th>Job Title Required</th>
			<th>Brief</th>
			<th>Web Disposition</th>
			<th>Staff Email Status</th>
			<th>Staff Email Status</th>
		</tr>
	</thead>
		
<?php
  $total_records = $result->rowCount();
	$total_pages = ceil($total_records / $limit);  
	$pagLink = "<div class='pagination'>";  
	for ($i=1; $i<=$total_pages; $i++) {  
  
 while($row=$result->fetch(PDO::FETCH_ASSOC))
  {
  ?>
	<tbody>
		<tr>
			<td><?php echo $row['date']; ?></td>
			<td><?php echo $row['btb']; ?></td>
			<td><?php echo $row['task']; ?></td>
			<td><?php echo $row['project_name']; ?></td>
			<td><?php echo $row['task_type']; ?></td>
			<td><?php echo $row['company_id']; ?></td>
			<td><?php echo $row['staff_id']; ?></td>
			<td><?php echo $row['parent_id']; ?></td>
			<td><?php echo $row['reference_code']; ?></td>
			<td><?php echo $row['company_received']; ?></td>
			<td><?php echo $row['company_name']; ?></td>
			<td><?php echo $row['company_disposition']; ?></td>
			<td><?php echo $row['company_telephone']; ?></td>
			<td><?php echo $row['alternate_telephone']; ?></td>
			<td><?php echo $row['company_fax']; ?></td>
			<td><?php echo $row['company_email']; ?></td>
			<td><?php echo $row['address']; ?></td>
			<td><?php echo $row['address_2']; ?></td>
			<td><?php echo $row['address_3']; ?></td>
			<td><?php echo $row['post_code']; ?></td>
			<td><?php echo $row['city']; ?></td>
			<td><?php echo $row['state']; ?></td>
			<td><?php echo $row['country']; ?></td>
			<td><?php echo $row['address_url']; ?></td>
			<td><?php echo $row['region']; ?></td>
			<td><?php echo $row['website']; ?></td>
			<td><?php echo $row['interest_area']; ?></td>
			<td><?php echo $row['industry']; ?></td>
			<td><?php echo $row['web_staff_disposition']; ?></td>
			<td><?php echo $row['voice_disposition']; ?></td>
			<td><?php echo $row['incomplete_disposition']; ?></td>
			<td><?php echo $row['researcher_remarks']; ?></td>
			<td><?php echo $row['caller_remarks']; ?></td>
			<td><?php echo $row['company_remarks']; ?></td>
			<td><?php echo $row['revenue_in_mil']; ?></td>
			<td><?php echo $row['number_of_employees']; ?></td>
			<td><?php echo $row['sic_code']; ?></td>
			<td><?php echo $row['sic_description']; ?></td>
			<td><?php echo $row['ca_1']; ?></td>
			<td><?php echo $row['ca_2']; ?></td>
			<td><?php echo $row['ca_3']; ?></td>
			<td><?php echo $row['ca_4']; ?></td>
			<td><?php echo $row['ca_5']; ?></td>
			<td><?php echo $row['title']; ?></td>
			<td><?php echo $row['first_name']; ?></td>
			<td><?php echo $row['initials']; ?></td>
			<td><?php echo $row['lastname']; ?></td>
			<td><?php echo $row['suffix']; ?></td>
			<td><?php echo $row['job_title']; ?></td>
			<td><?php echo $row['job_function']; ?></td>
			<td><?php echo $row['department']; ?></td>
			<td><?php echo $row['staff_url']; ?></td>
			<td><?php echo $row['staff_email']; ?></td>
			<td><?php echo $row['assumed_email']; ?></td>
			<td><?php echo $row['email_harvesting']; ?></td>
			<td><?php echo $row['direct_tel']; ?></td>
			<td><?php echo $row['extension']; ?></td>
			<td><?php echo $row['direct_fax']; ?></td>
			<td><?php echo $row['mobile']; ?></td>
			<td><?php echo $row['voice_staff_disposition']; ?></td>
			<td><?php echo $row['staff_remarks']; ?></td>
			<td><?php echo $row['sa_1']; ?></td>
			<td><?php echo $row['sa_2']; ?></td>
			<td><?php echo $row['sa_3']; ?></td>
			<td><?php echo $row['sa_4']; ?></td>
			<td><?php echo $row['sa_5']; ?></td>
			<td><?php echo $row['status']; ?></td>
			<td><?php echo $row['company_general_notes']; ?></td>
			<td><?php echo $row['staff_notes']; ?></td>
			<td><?php echo $row['job_title_required']; ?></td>
			<td><?php echo $row['brief']; ?></td>
			<td><?php echo $row['web_disposition']; ?></td>
			<td><?php echo $row['staff_email_status']; ?></td>
		</tr>
	</tbody>
        <?php  
		  $pagLink .= "<a href='view_data.php?page=".$i."' > ".$i."</a>";  
 }
  };  
echo $pagLink . "</div>"; 
 }
 ?>
 </div>
 
 
