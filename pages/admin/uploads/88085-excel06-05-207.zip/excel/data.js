$("#btn_submit").click(function () {       
        var record = $("#view_record").serialize();
		// console.log(record);
        $.ajax({
            type: "post",
            data: record,
           url: 'get_data00.php',
			// url: 'test.php',
			//url: 'new_test.php',
            success: function (result) {
				//console.log(result);
                $("#example").html(result);
            }
        })
});