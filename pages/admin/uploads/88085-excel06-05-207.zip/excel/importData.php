<?php
//load the database configuration file
include($_SERVER['DOCUMENT_ROOT']."/excel/config.php"); 

if(isset($_POST['importSubmit']))
{    
    //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes))
	{
        if(is_uploaded_file($_FILES['file']['tmp_name']))
		{
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            
            //skip first line
            fgetcsv($csvFile);
            
            //parse data from csv file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE){
                
				try {
                    //insert member data into database
					$query="INSERT INTO excel_data (date, btb, task, project_name,
							task_type, company_id, staff_id, parent_id,
							reference_code, company_received, company_name, 
							company_disposition, company_telephone, alternate_telephone,
							company_fax, company_email, address, address_2, address_3,
							post_code, city, state, country, address_url, region, 
							website, interest_area, industry, web_staff_disposition, 
							voice_disposition, incomplete_disposition, researche_remarks, 
							caller_remarks, company_remarks, revenue_in_mil, 
							number_of_employees, sic_code, sic_description, ca_1, 
							ca_2, ca_3, ca_4, ca_5, title, first_name, initials, 
							last_name, suffix, job_title, job_function, department,
							staff_url, staff_email, assumed_email, email_harvesting, 
							direct_tel, extension, direct_fax, mobile, voice_staff_disposition,
							staff_remarks, sa_1, sa_2, sa_3, sa_4, sa_5, status, 
							company_general_notes, staff_notes, job_title_required, brief,
							web_disposition, staff_email_status) 
							VALUES
							(now(),:btb,:task,:project_name,
							:task_type, :company_id, :staff_id, :parent_id,
							:reference_code, :company_received, :company_name, 
							:company_disposition, :company_telephone, :alternate_telephone,
							:company_fax, :company_email, :address, :address_2, :address_3,
							:post_code, :city, :state, :country, :address_url, :region, 
							:website, :interest_area, :industry, :web_staff_disposition, 
							:voice_disposition, :incomplete_disposition, :researcher_remarks, 
							:caller_remarks, :company_remarks, :revenue_in_mil, 
							:number_of_employees, :sic_code, :sic_description, :ca_1, 
							:ca_2, :ca_3, :ca_4, :ca_5, :title, :first_name, :initials, 
							:lastname, :suffix, :job_title, :job_function, :department,
							:staff_url, :staff_email, :assumed_email, :email_harvesting, 
							:direct_tel, :extension, :direct_fax, :mobile, :voice_staff_disposition,
							:staff_remarks, :sa_1, :sa_2, :sa_3, :sa_4, :sa_5, :status, 
							:company_general_notes, :staff_notes, :job_title_required, :brief,
							:web_disposition, :staff_email_status)";
							
							$stmt=$db_con->prepare($query);
							// $stmt->bindParam(':date',$line[0]);
							$stmt->bindParam(':btb',$line[0]);
							$stmt->bindParam(':task',$line[1]);
							$stmt->bindParam(':project_name',$line[2]);
							$stmt->bindParam(':task_type',$line[3]);
							$stmt->bindParam(':company_id',$line[4]);
							$stmt->bindParam(':staff_id',$line[5]);
							$stmt->bindParam(':parent_id',$line[6]);
							$stmt->bindParam(':reference_code',$line[7]);
							$stmt->bindParam(':company_received',$line[8]);
							$stmt->bindParam(':company_name',$line[9]);
							$stmt->bindParam(':company_disposition',$line[10]);
							$stmt->bindParam(':company_telephone',$line[11]);
							$stmt->bindParam(':alternate_telephone',$line[12]);
							$stmt->bindParam(':company_fax',$line[13]);
							$stmt->bindParam(':company_email',$line[14]);
							$stmt->bindParam(':address',$line[15]);
							$stmt->bindParam(':address_2',$line[16]);
							$stmt->bindParam(':address_3',$line[17]);
							$stmt->bindParam(':post_code',$line[18]);
							$stmt->bindParam(':city',$line[19]);
							$stmt->bindParam(':state',$line[20]);
							$stmt->bindParam(':country',$line[21]);
							$stmt->bindParam(':address_url',$line[22]);
							$stmt->bindParam(':region',$line[23]);
							$stmt->bindParam(':website',$line[24]);
							$stmt->bindParam(':interest_area',$line[25]);
							$stmt->bindParam(':industry',$line[26]);
							$stmt->bindParam(':web_staff_disposition',$line[27]);
							$stmt->bindParam(':voice_disposition',$line[28]);
							$stmt->bindParam(':incomplete_disposition',$line[29]);
							$stmt->bindParam(':researcher_remarks',$line[30]);
							$stmt->bindParam(':caller_remarks',$line[31]);
							$stmt->bindParam(':company_remarks',$line[32]);
							$stmt->bindParam(':revenue_in_mil',$line[33]);
							$stmt->bindParam(':number_of_employees',$line[34]);
							$stmt->bindParam(':sic_code',$line[35]);
							$stmt->bindParam(':sic_description',$line[36]);
							$stmt->bindParam(':ca_1',$line[37]);
							$stmt->bindParam(':ca_2',$line[38]);
							$stmt->bindParam(':ca_3',$line[39]);
							$stmt->bindParam(':ca_4',$line[40]);
							$stmt->bindParam(':ca_5',$line[41]);
							$stmt->bindParam(':title',$line[42]);
							$stmt->bindParam(':first_name',$line[43]);
							$stmt->bindParam(':initials',$line[44]);
							$stmt->bindParam(':lastname',$line[45]);
							$stmt->bindParam(':suffix',$line[46]);
							$stmt->bindParam(':job_title',$line[47]);
							$stmt->bindParam(':job_function',$line[48]);
							$stmt->bindParam(':department',$line[49]);
							$stmt->bindParam(':staff_url',$line[50]);
							$stmt->bindParam(':staff_email',$line[51]);
							$stmt->bindParam(':assumed_email',$line[52]);
							$stmt->bindParam(':email_harvesting',$line[53]);
							$stmt->bindParam(':direct_tel',$line[54]);
							$stmt->bindParam(':extension',$line[55]);
							$stmt->bindParam(':direct_fax',$line[56]);
							$stmt->bindParam(':mobile',$line[57]);
							$stmt->bindParam(':voice_staff_disposition',$line[58]);
							$stmt->bindParam(':staff_remarks',$line[59]);
							$stmt->bindParam(':sa_1',$line[60]);
							$stmt->bindParam(':sa_2',$line[61]);
							$stmt->bindParam(':sa_3',$line[62]);
							$stmt->bindParam(':sa_4',$line[63]);
							$stmt->bindParam(':sa_5',$line[64]);
							$stmt->bindParam(':status',$line[65]);
							$stmt->bindParam(':company_general_notes',$line[66]);
							$stmt->bindParam(':staff_notes',$line[67]);
							$stmt->bindParam(':job_title_required',$line[68]);
							$stmt->bindParam(':brief',$line[69]);
							$stmt->bindParam(':web_disposition',$line[70]);
							$stmt->bindParam(':staff_email_status',$line[71]);
							$stmt->execute();
							if($stmt->execute())
							{
								if($stmt->rowCount()!== 0 )
								{
									echo "<script>window.location.href ='view_data.php';</script>";
									echo 'data inserted';
								}
								else {
									echo 'error';
								}
							}else {
								echo 'unable to insert';
							}
						}
						catch(PDOException $e)
							{
								echo  $e->getMessage();

							}
				
				
			}
            //close opened csv file
            fclose($csvFile);
            $qstring = '?status=succ';
        }
		else{
            $qstring = '?status=err';
        }
    }
	else
	{
        $qstring = '?status=invalid_file';
    }
}
//redirect to the listing page
header("Location: excel_upload.php".$qstring);