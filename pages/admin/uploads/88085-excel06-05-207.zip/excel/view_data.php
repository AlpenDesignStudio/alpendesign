<?php
include($_SERVER['DOCUMENT_ROOT']."/excel/config.php"); 
	
$btb=$_GET['ddl_btb'];
$task=$_GET['ddl_task'];
$proj_name=$_GET['ddl_proj_name'];
$task_type=$_GET['ddl_task_type'];
$company_id=$_GET['ddl_company_id'];
$company_name=$_GET['ddl_company_name'];
$state=$_GET['ddl_state'];
$country=$_GET['ddl_country'];
$website=$_GET['ddl_website'];
$industry=$_GET['ddl_industry'];
$no_of_emp=$_GET['ddl_no_of_emp'];
$f_name=$_GET['ddl_f_name'];
$l_name=$_GET['ddl_l_name'];
$job_title=$_GET['ddl_job_title'];
$job_func=$_GET['ddl_job_func'];
$staff_email=$_GET['ddl_staff_email'];

$WhereAnd = 'where';
function getWhereAnd() {
  global $WhereAnd;
  if ($WhereAnd == 'where') {
    $WhereAnd = 'and';
    return ' where ';
  } else {
    return ' and ';
  }
}
$TempSQL = "SELECT field1, field2, field3 FROM table WHERE ";
$args=array();


$limit=30;
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
		$start_from = ($page-1) * 3; 


$q = 'SELECT * FROM excel_data'; 
	 if(!empty($btb)){
		$q .=  getWhereAnd() . "btb=:btb";
		$args[':btb']=$btb;
	 }
	 if(!empty($task)){
		  $q .=  getWhereAnd() . "task=:task";
		  $args[':task']=$task;
		}	
	 if(!empty($proj_name)){
		$q .=  getWhereAnd() . "project_name=:proj_name";
		$args[':proj_name']=$proj_name;
		}
	 if(!empty($task_type)){
		 $q .=  getWhereAnd() . "task_type=:task_type";
		 $args[':task_type']=$task_type;
		}
	 if(!empty($company_id)){
		 $q .=  getWhereAnd() . "company_id=:company_id";
		 $args[':company_id']=$company_id;
		}
	 if(!empty($company_name)){	
		 $q .=  getWhereAnd() . "company_name=:company_name";
		 $args[':company_name']=$company_name;
		}
	 if(!empty($state)){
		 $q .=  getWhereAnd() . "state=:state";
		 $args[':state']=$state;
		}
	if(!empty($country)){
		$q .=  getWhereAnd() . "country=:country";
		$args[':country']=$country;
		}
	 if(!empty($website)){
		 $q .=  getWhereAnd() . "website=:website";
		 $args[':website']=$website;
		}
	if(!empty($industry)){	
		$q .=  getWhereAnd() . "industry=:industry";
		$args[':industry']=$industry;
		}
	 if(!empty($no_of_emp)){	
		$q .=  getWhereAnd() . "number_of_employees=:no_of_emp";
		$args[':no_of_emp']=$no_of_emp;		
			}
	if(!empty($f_name)){	
		$q .=  getWhereAnd() . "first_name=:f_name";
		$args[':f_name']=$f_name;
		}
	 if(!empty($l_name)){	
		$q .=  getWhereAnd() . "last_name=:l_name";
		$args[':l_name']=$l_name;		
		}
	if(!empty($job_title)){	
		$q .=  getWhereAnd() . "job_title=:job_title";
		$args[':job_title']=$job_title;
		}
	if(!empty($job_func)){		
		$q .=  getWhereAnd() . "job_function=:job_func";
		$args[':job_func']=$job_func;
		}
	if(!empty($staff_url)){	
		$q .=  getWhereAnd() . "staff_url=:staff_url";
		$args[':staff_url']=$staff_url;
		}	
	 if(!empty($staff_url)){	
	 $q .=  getWhereAnd() . "staff_email=:staff_email";
	 $args[':staff_email']=$staff_email;
		}

	
	$q.=  " ORDER BY id ASC LIMIT " . $start_from .','.$limit;
	// echo $q;
	$result=$db_con->prepare($q);
	$result->execute($args);
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Import CSV File</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css">
  <link rel="stylesheet" href="style.css">

  
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="//code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>
	<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>
	

</head>
	<body>
		<div class="container">
				<div class="panel-body">
					<form method="GET" action="view_data1.php" class="form-inline">	
					<div class="panel-heading">
						<h3> Filter Data</h3>
							<div class="box-body">
								<div class="form-group">	
									<label>Project Name : </label> 
									
									<input list="ddl_proj_name" name="ddl_proj_name">							
									<datalist name="ddl_proj_name" id="ddl_proj_name">
										<option selected="selected">--Select project_name--</option>
										<?php
										$query="SELECT distinct(`project_name`) FROM `excel_data` ORDER BY project_name ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['project_name'];?>"><?php echo $row['project_name'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>	
								
								<div class="form-group">
									<label>Task Type : </label> 
						
									<input list="ddl_task_type" name="ddl_task_type">							
									<datalist name="ddl_task_type" id="ddl_task_type">
										<option selected="selected">--Select task_type--</option>
										<?php
										$query="SELECT distinct(`task_type`) FROM `excel_data` ORDER BY task_type ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['task_type']; ?>"><?php echo $row['task_type'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								<div class="form-group">
									<label>Company Id :</label>
								
									<input list="ddl_company_id" name="ddl_company_id">							
									<datalist name="ddl_company_id" id="ddl_company_id">
										<option selected="selected">--Select company_id--</option>
										<?php
										$query="SELECT distinct(`company_id`) FROM `excel_data` ORDER BY company_id ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['company_id']; ?>"><?php echo $row['company_id'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>	
								
								<div class="form-group">
									<label>Company Name :</label> 
								
									<input list="ddl_company_name" name="ddl_company_name">							
									<datalist name="ddl_company_name" id="ddl_company_name">
										<option selected="selected">--Select company_name--</option>
										<?php
										$query="SELECT distinct(`company_name`) FROM `excel_data` ORDER BY company_name ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['company_name'];?>"><?php echo $row['company_name'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								<div class="form-group">
									<label>State :</label> 
								
										<input list="ddl_state" name="ddl_state">							
										<datalist name="ddl_state" id="ddl_state">
											<option selected="selected">--Select state--</option>
											<?php
											$query="SELECT distinct(`state`) FROM `excel_data` ORDER BY state ASC";
											
											$stmt=$db_con->query($query);
											$stmt->execute();
											if($stmt->rowCount() != 0){
											while($row=$stmt->fetch()){
											  ?>
											<option value="<?php echo $row['state']; ?>"><?php echo $row['state'];?></option>
											<?php	}
											}
											else {
												echo "NO DATA SELECTED";
											}
												?>
										</datalist>
									</div>
								 
								<div class="form-group">
									<label>Country :</label>
															
									<input list="ddl_country" name="ddl_country">							
									<datalist name="ddl_country" id="ddl_country">
										<option selected="selected">--Select country--</option>
										<?php
										$query="SELECT distinct(`country`) FROM `excel_data` ORDER BY country ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['country']; ?>"><?php echo $row['country'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								
								<div class="form-group">
									<label>Website :</label> 
														
									<input list="ddl_website" name="ddl_website">							
									<datalist name="ddl_website" id="ddl_website">
										<option selected="selected">--Select website--</option>
										<?php
										$query="SELECT distinct(`website`) FROM `excel_data` ORDER BY website ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['website']; ?>"><?php echo $row['website'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								<div class="form-group">
									<label>Industry : </label>
														
									<input list="ddl_industry" name="ddl_industry">							
									<datalist name="ddl_industry" id="ddl_industry">
										<option selected="selected">--Select industry--</option>
										<?php
										$query="SELECT distinct(`industry`) FROM `excel_data` ORDER BY industry ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['industry']; ?>"><?php echo $row['industry'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								<div class="form-group">
									<label>Number Of Employees :</label> 
													
									<input list="ddl_no_of_emp" name="ddl_no_of_emp">							
									<datalist name="ddl_no_of_emp" id="ddl_no_of_emp">						
										<option  selected="selected">--Select number_of_employees--</option>
										<?php
										$query="SELECT distinct(`number_of_employees`) FROM `excel_data` ORDER BY number_of_employees ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['number_of_employees']; ?>"><?php echo $row['number_of_employees']; ?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								<div class="form-group">
									<label>First Name :</label> 
														
									<input list="ddl_f_name" name="ddl_f_name">							
									<datalist name="ddl_f_name" id="ddl_f_name">
										<option selected="selected">--Select first_name--</option>
										<?php
										$query="SELECT distinct(`first_name`) FROM `excel_data` ORDER BY first_name ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['first_name']; ?>"><?php echo $row['first_name']; ?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								<div class="form-group">
									<label>Last Name :</label> 
								
									<input list="ddl_l_name" name="ddl_l_name">							
									<datalist name="ddl_l_name" id="ddl_l_name">
										<option selected="selected">--Select lastname--</option>
										<?php
										$query="SELECT distinct(`last_name`) FROM `excel_data` ORDER BY last_name ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['last_name']; ?>"><?php echo $row['last_name'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								
								<div class="form-group">
									<label>Job Title :</label> 
								
									<input list="ddl_job_title" name="ddl_job_title">							
									<datalist name="ddl_job_title" id="ddl_job_title">
									<option selected="selected">--Select job_title--</option>
										<?php
										$query="SELECT distinct(`job_title`) FROM `excel_data` ORDER BY job_title ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['job_title']; ?>"><?php echo $row['job_title'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								<div class="form-group">
									<label>Job Function :</label> 
								
									<input list="ddl_job_func" name="ddl_job_func">							
									<datalist name="ddl_job_func" id="ddl_job_func">
										<option selected="selected">--Select job_function--</option>
										<?php
										$query="SELECT distinct(`job_function`) FROM `excel_data` ORDER BY job_function ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['job_function'];?>"><?php echo $row['job_function'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>	
								</div>
								
								<div class="form-group">
									<label>Staff Email : </label> 
								
									<input list="ddl_staff_email" name="ddl_staff_email">							
									<datalist name="ddl_staff_email" id="ddl_staff_email">
										<option  selected="selected">--Select staff_email--</option>
										<?php
										$query="SELECT distinct(`staff_email`) FROM `excel_data` ORDER BY staff_email ASC";
										
										$stmt=$db_con->query($query);
										$stmt->execute();
										if($stmt->rowCount() != 0){
										while($row=$stmt->fetch()){
										  ?>
										<option value="<?php echo $row['number_of_employees']; ?>"><?php echo $row['staff_email'];?></option>
										<?php	}
										}
										else {
											echo "NO DATA SELECTED";
										}
											?>
									</datalist>
								</div>
								
								<div class="form-group">
									<input type="submit" value="Search" />
								</div>
							</div>
			
					<div class="table-responsive">
					<table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" cellpadding="2">
					<thead>
					<tr>
					<th>Date</th>
						<th>BTB</th>
						<th>Task</th>
						<th>Project Name</th>
						<th>Task Type</th>
						<th>Company ID</th>
						<th>Staff ID</th>
						<th>Parent ID</th>
						<th>Reference Code</th>
						<th>Company Received</th>
						<th>Company Name</th>
						<th>Company Disposition</th>
						<th>Company Telephone</th>
						<th>Alternate Telephone</th>
						<th>Company Fax</th>
						<th>Company Email</th>
						<th>Address</th>
						<th>Address 2</th>
						<th>Address 3</th>
						<th>Post Code</th>
						<th>City</th>
						<th>State</th>
						<th>Country</th>
						<th>Address URL</th>
						<th>REGION</th>
						<th>WEBSITE</th>
						<th>Interest Area</th>
						<th>INDUSTRY</th>
						<th>Web Staff Disposition</th>
						<th>Voice Disposition</th>
						<th>Incomplete Disposition</th>
						<th>Researcher Remarks</th>
						<th>Caller Remarks</th>
						<th>Company Remarks</th>
						<th>Revenue (In Mil)</th>
						<th>Number of Employees</th>
						<th>SIC Code</th>
						<th>SIC Description</th>
						<th>CA 1</th>
						<th>CA 2</th>
						<th>CA 3</th>
						<th>CA 4</th>
						<th>CA 5</th>
						<th>Title</th>
						<th>First Name</th>
						<th>INITIALS</th>
						<th>LASTNAME</th>
						<th>SUFFIX</th>
						<th>Job Title</th>
						<th>Job Function</th>
						<th>Department</th>
						<th>Staff Url</th>
						<th>Staff Email</th>
						<th>Assumed Email</th>
						<th>Email Harvesting</th>
						<th>Direct Tel</th>
						<th>EXTENSION</th>
						<th>Direct Fax</th>
						<th>Mobile</th>
						<th>Voice Staff Disposition</th>
						<th>Staff Remarks</th>
						<th>SA 1</th>
						<th>SA 2</th>
						<th>SA 3</th>
						<th>SA 4</th>
						<th>SA 5</th>
						<th>Status</th>
						<th>Company General Notes</th>
						<th>Staff Notes</th>
						<th>Job Title Required</th>
						<th>Brief</th>
						<th>Web Disposition</th>
						<th>Staff Email Status</th>
						<th>Staff Email Status</th>
				</tr>
			</thead>
		<tbody>
				<?php
				
					if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
					$start_from = ($page-1) * 3; 		
					$stmt = $db_con->prepare($q);
					$result->execute();
					for($i=0; $row = $result->fetch(); $i++){
				?>
				<tr class="record">
					<td><?php echo $row['date']; ?></td>
						<td><?php echo $row['btb']; ?></td>
						<td><?php echo $row['task']; ?></td>
						<td><?php echo $row['project_name']; ?></td>
						<td><?php echo $row['task_type']; ?></td>
						<td><?php echo $row['company_id']; ?></td>
						<td><?php echo $row['staff_id']; ?></td>
						<td><?php echo $row['parent_id']; ?></td>
						<td><?php echo $row['reference_code']; ?></td>
						<td><?php echo $row['company_received']; ?></td>
						<td><?php echo $row['company_name']; ?></td>
						<td><?php echo $row['company_disposition']; ?></td>
						<td><?php echo $row['company_telephone']; ?></td>
						<td><?php echo $row['alternate_telephone']; ?></td>
						<td><?php echo $row['company_fax']; ?></td>
						<td><?php echo $row['company_email']; ?></td>
						<td><?php echo $row['address']; ?></td>
						<td><?php echo $row['address_2']; ?></td>
						<td><?php echo $row['address_3']; ?></td>
						<td><?php echo $row['post_code']; ?></td>
						<td><?php echo $row['city']; ?></td>
						<td><?php echo $row['state']; ?></td>
						<td><?php echo $row['country']; ?></td>
						<td><?php echo $row['address_url']; ?></td>
						<td><?php echo $row['region']; ?></td>
						<td><?php echo $row['website']; ?></td>
						<td><?php echo $row['interest_area']; ?></td>
						<td><?php echo $row['industry']; ?></td>
						<td><?php echo $row['web_staff_disposition']; ?></td>
						<td><?php echo $row['voice_disposition']; ?></td>
						<td><?php echo $row['incomplete_disposition']; ?></td>
						<td><?php echo $row['researcher_remarks']; ?></td>
						<td><?php echo $row['caller_remarks']; ?></td>
						<td><?php echo $row['company_remarks']; ?></td>
						<td><?php echo $row['revenue_in_mil']; ?></td>
						<td><?php echo $row['number_of_employees']; ?></td>
						<td><?php echo $row['sic_code']; ?></td>
						<td><?php echo $row['sic_description']; ?></td>
						<td><?php echo $row['ca_1']; ?></td>
						<td><?php echo $row['ca_2']; ?></td>
						<td><?php echo $row['ca_3']; ?></td>
						<td><?php echo $row['ca_4']; ?></td>
						<td><?php echo $row['ca_5']; ?></td>
						<td><?php echo $row['title']; ?></td>
						<td><?php echo $row['first_name']; ?></td>
						<td><?php echo $row['initials']; ?></td>
						<td><?php echo $row['lastname']; ?></td>
						<td><?php echo $row['suffix']; ?></td>
						<td><?php echo $row['job_title']; ?></td>
						<td><?php echo $row['job_function']; ?></td>
						<td><?php echo $row['department']; ?></td>
						<td><?php echo $row['staff_url']; ?></td>
						<td><?php echo $row['staff_email']; ?></td>
						<td><?php echo $row['assumed_email']; ?></td>
						<td><?php echo $row['email_harvesting']; ?></td>
						<td><?php echo $row['direct_tel']; ?></td>
						<td><?php echo $row['extension']; ?></td>
						<td><?php echo $row['direct_fax']; ?></td>
						<td><?php echo $row['mobile']; ?></td>
						<td><?php echo $row['voice_staff_disposition']; ?></td>
						<td><?php echo $row['staff_remarks']; ?></td>
						<td><?php echo $row['sa_1']; ?></td>
						<td><?php echo $row['sa_2']; ?></td>
						<td><?php echo $row['sa_3']; ?></td>
						<td><?php echo $row['sa_4']; ?></td>
						<td><?php echo $row['sa_5']; ?></td>
						<td><?php echo $row['status']; ?></td>
						<td><?php echo $row['company_general_notes']; ?></td>
						<td><?php echo $row['staff_notes']; ?></td>
						<td><?php echo $row['job_title_required']; ?></td>
						<td><?php echo $row['brief']; ?></td>
						<td><?php echo $row['web_disposition']; ?></td>
						<td><?php echo $row['staff_email_status']; ?></td>
					</tr>
					<?php
						}
					?>
			</tbody>
			</table>
			<div id="pagination">
				<?php 
				$WhereAnd = 'where';
				$query = 'SELECT COUNT(id) FROM excel_data'; 
				 if(!empty($btb)){
					$query .=  getWhereAnd() . "btb=:btb";
					$args[':btb']=$btb;
				 }
				 if(!empty($task)){
					  $query .=  getWhereAnd() . "task=:task";
					  $args[':task']=$task;
					}	
				 if(!empty($proj_name)){
					$query .=  getWhereAnd() . "project_name=:proj_name";
					$args[':proj_name']=$proj_name;
					}
				 if(!empty($task_type)){
					 $query .=  getWhereAnd() . "task_type=:task_type";
					 $args[':task_type']=$task_type;
					}
				 if(!empty($company_id)){
					 $query .=  getWhereAnd() . "company_id=:company_id";
					 $args[':company_id']=$company_id;
					}
				 if(!empty($company_name)){	
					 $query .=  getWhereAnd() . "company_name=:company_name";
					 $args[':company_name']=$company_name;
					}
				 if(!empty($state)){
					 $query .=  getWhereAnd() . "state=:state";
					 $args[':state']=$state;
					}
				if(!empty($country)){
					$query .=  getWhereAnd() . "country=:country";
					$args[':country']=$country;
					}
				 if(!empty($website)){
					 $query .=  getWhereAnd() . "website=:website";
					 $args[':website']=$website;
					}
				if(!empty($industry)){	
					$query .=  getWhereAnd() . "industry=:industry";
					$args[':industry']=$industry;
					}
				 if(!empty($no_of_emp)){	
					$query .=  getWhereAnd() . "number_of_employees=:no_of_emp";
					$args[':no_of_emp']=$no_of_emp;		
						}
				if(!empty($f_name)){	
					$query .=  getWhereAnd() . "first_name=:f_name";
					$args[':f_name']=$f_name;
					}
				 if(!empty($l_name)){	
					$query .=  getWhereAnd() . "last_name=:l_name";
					$args[':l_name']=$l_name;		
					}
				if(!empty($job_title)){	
					$query .=  getWhereAnd() . "job_title=:job_title";
					$args[':job_title']=$job_title;
					}
				if(!empty($job_func)){		
					$query .=  getWhereAnd() . "job_function=:job_func";
					$args[':job_func']=$job_func;
					}
				if(!empty($staff_url)){	
					$query .=  getWhereAnd() . "staff_url=:staff_url";
					$args[':staff_url']=$staff_url;
					}	
				 if(!empty($staff_url)){	
				 $query .=  getWhereAnd() . "staff_email=:staff_email";
				 $args[':staff_email']=$staff_email;
				}


					//echo $query;
				$results=$db_con->prepare($query);
				$results->execute($args);
							
				$row = $results->fetch(); 
				$total_records = $row[0]; 
				$total_pages = ceil($total_records / 3); 
				  
				for ($i=1; $i<=$total_pages; $i++) { 
				echo "<a href='view_data1.php?page=".$i."&ddl_proj_name=".$proj_name."&ddl_task_type=".$task_type."&ddl_company_id=".$company_id."&ddl_company_name=".$company_name."&ddl_state=".$state."&ddl_country=".$country."&ddl_website=".$website."&ddl_industry=".$industry."&ddl_no_of_emp=".$no_of_emp."&ddl_f_name=".$f_name."&ddl_l_name=".$l_name."&ddl_job_title=".$job_title."&ddl_job_func=".$job_func."&ddl_staff_email=".$staff_email."'";

				//echo "<a href='view_data1.php?page=".$i."&ddl_proj_name=".$proj_name."&ddl_task_type=".$task_type."&ddl_company_id=".$company_id."&ddl_company_name=".$ddl_state."&ddl_proj_name=".$ddl_country."&ddl_proj_name=".$ddl_website."&ddl_proj_name=".$ddl_industry."&ddl_proj_name=".$ddl_no_of_emp."&ddl_proj_name=".$ddl_f_name."&ddl_proj_name=".$ddl_l_name."&ddl_proj_name=".$ddl_proj_name."'";
				if($page==$i)
				{
				echo "id=active";
				}
				echo ">";
				echo "".$i."</a> "; 									
				}; 
				?>
			</div>
				</div>
				</form>
				</div>
				
			</div>
		</div>		
	</body>
</html>